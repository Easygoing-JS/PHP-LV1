-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 06 2020 г., 13:45
-- Версия сервера: 5.6.43
-- Версия PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson7_shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `authors`
--

CREATE TABLE `authors` (
  `id_author` int(11) NOT NULL,
  `rights` int(11) NOT NULL DEFAULT '3',
  `author_name` varchar(100) NOT NULL,
  `author_family` varchar(100) NOT NULL,
  `author_login` varchar(100) NOT NULL,
  `author_pass` varchar(100) NOT NULL,
  `author_email` varchar(100) NOT NULL,
  `date_reg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `authors`
--

INSERT INTO `authors` (`id_author`, `rights`, `author_name`, `author_family`, `author_login`, `author_pass`, `author_email`, `date_reg`) VALUES
(7, 3, 'Вова', 'Гундин', 'easy', '$2y$10$Tbw7hOarj3L8DuK2YFXRReKk2TFFQtV1Rp5kemHbDyMYkElM6liVq', 'gundin87@gmail.com', 1580840917),
(8, 3, 'name', 'surname', 'zero', '$2y$10$j0pi4.ULo8bKjGhgNjZuqev2WBqU2kTiXGet2LZL/HWAwvwf7SjiK', 'email@mail.com', 1580924789);

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `user_cookie` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `num_product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

CREATE TABLE `photos` (
  `id_photo` int(11) NOT NULL,
  `photo_big` varchar(50) NOT NULL,
  `photo_thumb` varchar(50) NOT NULL,
  `photo_alt` varchar(50) NOT NULL,
  `likes` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id_photo`, `photo_big`, `photo_thumb`, `photo_alt`, `likes`) VALUES
(1, '/img/big/city.jpg', '/img/thumb/city.jpg', '', 16),
(5, '/img/big/sea.jpg', '/img/thumb/sea.jpg', '', 2),
(6, '/img/big/street.jpg', '/img/thumb/street.jpg', '', 6);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id_product` int(11) NOT NULL,
  `product_name` varchar(70) NOT NULL,
  `product_text` text NOT NULL,
  `price` int(11) NOT NULL,
  `photo_big` varchar(100) NOT NULL,
  `photo_thumb` varchar(100) NOT NULL,
  `product_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id_product`, `product_name`, `product_text`, `price`, `photo_big`, `photo_thumb`, `product_time`) VALUES
(3, 'Товар №1', 'Описание товара', 1000, '/img/big/city.jpg', '/img/thumb/city.jpg', 1539252910),
(5, 'Товар №2', 'Описание товара', 800, '/img/big/sea.jpg', '/img/thumb/sea.jpg', 1539255628),
(6, 'Товар №3', 'Описание товара', 700, '', '', 1539255716),
(7, 'Товар №4', 'Описание товара', 2000, '/img/big/street.jpg', '/img/thumb/street.jpg', 1539255787),
(8, 'товар-ноль', 'тестовый ввод нового товара', 9000, '', '', 1580842195);

-- --------------------------------------------------------

--
-- Структура таблицы `products_groups`
--

CREATE TABLE `products_groups` (
  `id_group` int(11) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `id_group_parent` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `products_groups`
--

INSERT INTO `products_groups` (`id_group`, `group_name`, `id_group_parent`) VALUES
(1, 'Игрушки', 0),
(2, 'Машинки', 1),
(3, 'Куклы', 1),
(4, 'Книги', 0),
(5, 'Программирование', 4),
(6, 'Математика', 4),
(7, 'Посуда', 1),
(8, 'Герои', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `products_photos`
--

CREATE TABLE `products_photos` (
  `id_photo` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `photo_thumb` varchar(100) NOT NULL,
  `photo_big` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `uid_groups`
--

CREATE TABLE `uid_groups` (
  `uid_groups` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `id_product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `uid_groups`
--

INSERT INTO `uid_groups` (`uid_groups`, `id_group`, `id_product`) VALUES
(7, 1, 3),
(8, 2, 3),
(10, 1, 7),
(11, 8, 7),
(12, 1, 6),
(13, 7, 6);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id_author`),
  ADD KEY `rights` (`rights`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Индексы таблицы `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id_photo`),
  ADD KEY `like` (`likes`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_product`),
  ADD KEY `product_time` (`product_time`);

--
-- Индексы таблицы `products_groups`
--
ALTER TABLE `products_groups`
  ADD PRIMARY KEY (`id_group`),
  ADD KEY `id_group_parent` (`id_group_parent`);

--
-- Индексы таблицы `products_photos`
--
ALTER TABLE `products_photos`
  ADD PRIMARY KEY (`id_photo`),
  ADD KEY `id_product` (`id_product`);

--
-- Индексы таблицы `uid_groups`
--
ALTER TABLE `uid_groups`
  ADD PRIMARY KEY (`uid_groups`),
  ADD KEY `id_group` (`id_group`),
  ADD KEY `id_product` (`id_product`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `authors`
--
ALTER TABLE `authors`
  MODIFY `id_author` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `photos`
--
ALTER TABLE `photos`
  MODIFY `id_photo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `products_groups`
--
ALTER TABLE `products_groups`
  MODIFY `id_group` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `products_photos`
--
ALTER TABLE `products_photos`
  MODIFY `id_photo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `uid_groups`
--
ALTER TABLE `uid_groups`
  MODIFY `uid_groups` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
